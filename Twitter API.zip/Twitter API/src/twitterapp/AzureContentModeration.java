package twitterapp;
import java.net.URI;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class AzureContentModeration 
{
    public static ArrayList<String> evaluateImage(String url)
    {
        HttpClient httpclient = HttpClients.createDefault();
        ArrayList<String> ar = new ArrayList<String>();
        try
        {
            URIBuilder builder = new URIBuilder("https://eastasia.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0/ProcessImage/Evaluate");

            builder.setParameter("CacheImage", "false");

            URI uri = builder.build();
            HttpPost request = new HttpPost(uri);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Ocp-Apim-Subscription-Key", "fb76950928da4c4498632fc17203e83b");


            // Request body
            StringEntity reqEntity = new StringEntity("{\r\n" + 
            		"  \"DataRepresentation\":\"URL\",\r\n" + 
            		"  \"Value\":\""+url+"\"\r\n" + 
            		"}");
            request.setEntity(reqEntity);

            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();
            
            if (entity != null) 
            {
            	String s = EntityUtils.toString(entity);
   			 JSONObject object = new JSONObject(s);
   			 System.out.println(object);
                Double AdultClassificationScore = object.getDouble("AdultClassificationScore");
                Double RacyClassificationScore = object.getDouble("RacyClassificationScore");
                Boolean isImageRacyClassified = object.getBoolean("IsImageRacyClassified");
                Boolean isImageAdultClassified = object.getBoolean("IsImageAdultClassified");
                RacyClassificationScore = (double) Math.round(RacyClassificationScore * 100);
                AdultClassificationScore = (double) Math.round(AdultClassificationScore * 100);
                
                String adultClassificationString = Double.toString(AdultClassificationScore);
                String racyClassificationString = Double.toString(RacyClassificationScore);
                ar.add(adultClassificationString);
                String isImageAdult = Boolean.toString(isImageAdultClassified);
                String isImageRacy = Boolean.toString(isImageRacyClassified);
                ar.add(isImageAdult);
                ar.add(racyClassificationString);
                ar.add(isImageRacy);
                return ar;
                
            }
        }
        catch (Exception e)
        {
            ar.add("error");
        }
        return ar;
    }
    
    
    public ArrayList<Integer>  findFaces(String url)
    {

        HttpClient httpclient = HttpClients.createDefault();
        ArrayList<Integer> ar = new ArrayList<Integer>();
        try
        {
            URIBuilder builder = new URIBuilder("https://eastasia.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0/ProcessImage/FindFaces");

            builder.setParameter("CacheImage", "false");

            URI uri = builder.build();
            HttpPost request = new HttpPost(uri);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Ocp-Apim-Subscription-Key", "fb76950928da4c4498632fc17203e83b");


            // Request body
            StringEntity reqEntity = new StringEntity("{\r\n" + 
            		"  \"DataRepresentation\":\"URL\",\r\n" + 
            		"  \"Value\":\""+url+"\"\r\n" + 
            		"}");
            request.setEntity(reqEntity);
            
            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();
            System.out.println("hello1");
            if (entity != null) 
            {
            	String s = EntityUtils.toString(entity);
      			 JSONObject object = new JSONObject(s);
      			 int count = object.getInt("Count");
      			System.out.println("count"+count);
      			ar.add(count);
      			 if(count>0)
      			 {
      				 JSONArray faces = object.getJSONArray("Faces");
      				 int i;
      				 for(i=0; i<faces.length();i++)
      				 {
      					 JSONObject face = faces.getJSONObject(i);
      					 int left = face.getInt("Left");
      					int right = face.getInt("Right");
      					int top = face.getInt("Top");
      					int bottom = face.getInt("Bottom");
      					
      					ar.add(left);
      					ar.add(right);
      					ar.add(top);
      					ar.add(bottom);
      					
      				 }
      			 }
            
            }
        }
        catch (Exception e)
        {
        	ar.add(-1);
            System.out.println(e.getMessage());
        }
        System.out.println(ar);
		return ar;
    }
    
    public String ocr(String url)
    {
    	HttpClient httpclient = HttpClients.createDefault();
    	String text="";
        try
        {
            URIBuilder builder = new URIBuilder("https://eastasia.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0/ProcessImage/OCR");

            builder.setParameter("language", "eng");
            builder.setParameter("CacheImage", "false");
            builder.setParameter("enhanced", "false");

            URI uri = builder.build();
            HttpPost request = new HttpPost(uri);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Ocp-Apim-Subscription-Key", "fb76950928da4c4498632fc17203e83b");


            // Request body
            StringEntity reqEntity = new StringEntity("{\r\n" + 
            		"  \"DataRepresentation\":\"URL\",\r\n" + 
            		"  \"Value\":\""+url+"\"\r\n" + 
            		"}");
            request.setEntity(reqEntity);

            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();

            if (entity != null) 
            {
            	String s = EntityUtils.toString(entity);
     			 JSONObject object = new JSONObject(s);
     			 text = object.getString("Text");   
     			 System.out.println(text);
            }
        }
        catch (Exception e)
        {
        	System.out.println(e);
            return "error";
        }
		return text;
    }
    
    public String detectLanguage(String text)
    {
    	HttpClient httpclient = HttpClients.createDefault();

        try
        {
            URIBuilder builder = new URIBuilder("https://eastasia.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0/ProcessText/DetectLanguage");


            URI uri = builder.build();
            HttpPost request = new HttpPost(uri);
            request.setHeader("Content-Type", "text/plain");
            request.setHeader("Ocp-Apim-Subscription-Key", "fb76950928da4c4498632fc17203e83b");


            // Request body
            StringEntity reqEntity = new StringEntity(text);
            request.setEntity(reqEntity);

            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();

            if (entity != null) 
            {
            	String s = EntityUtils.toString(entity);
    			 JSONObject object = new JSONObject(s);
    			 String lang = object.getString("DetectedLanguage");
    			 return lang;
            }
        }
        catch (Exception e)
        {
            return "|||error|||";
        }
		return text;
    }
    
    public ArrayList<String> detectPersonalInfo(String text)
    {
    	 HttpClient httpclient = HttpClients.createDefault();
    	 ArrayList<String> ar = new ArrayList<String>();
    	 int i;
         try
         {
             URIBuilder builder = new URIBuilder("https://eastasia.api.cognitive.microsoft.com/contentmoderator/moderate/v1.0/ProcessText/Screen");

             builder.setParameter("autocorrect", "true");
             builder.setParameter("PII", "true");
             builder.setParameter("classify", "True");

             URI uri = builder.build();
             HttpPost request = new HttpPost(uri);
             request.setHeader("Content-Type", "text/plain");
             request.setHeader("Ocp-Apim-Subscription-Key", "fb76950928da4c4498632fc17203e83b");


             // Request body
             StringEntity reqEntity = new StringEntity(text);
             request.setEntity(reqEntity);

             HttpResponse response = httpclient.execute(request);
             HttpEntity entity = response.getEntity();

             if (entity != null) 
             {
            	 String s = EntityUtils.toString(entity);
    			 JSONObject object = new JSONObject(s);
    			 if(object.has("PII"))
    			 {
	    			 JSONObject pii = object.getJSONObject("PII");
	    			 if(pii.has("Email"))
	    			 {
	    				 
	    				JSONArray email = pii.getJSONArray("Email");
	    				for(i=0;i<email.length();i++)
	    				{
	    					JSONObject edetails = email.getJSONObject(i);
	    					String email_detail = edetails.getString("Text");
	    					ar.add("Detected email: "+email_detail);
	    				}
	    			 }
	    			 if(pii.has("Phone"))
	    			 {
	    				 JSONArray phoneNos = pii.getJSONArray("Phone");
		    				for(i=0;i<phoneNos.length();i++)
		    				{
		    					JSONObject phoneNumbers = phoneNos.getJSONObject(i);
		    					String phone = phoneNumbers.getString("Text");
		    					ar.add("Detected Phone Number: "+phone);
		    				}
		    		 }
	    			 if(pii.has("Address"))
	    			 {
	    				 JSONArray Addresses = pii.getJSONArray("Address");
		    				for(i=0;i<Addresses.length();i++)
		    				{
		    					JSONObject AddressDetails = Addresses.getJSONObject(i);
		    					String address = AddressDetails.getString("Text");
		    					ar.add("Detected Personal address: "+address);
		    				}
		    		 }
	            	 
    			 }
    			 else
    			 {
    				 ar.add("No personal Information Found");
    			 }
    			 return ar;
             }
         }
         catch (Exception e)
         {
             ar.add("error");
             return ar;
         }
         return ar;
    }
    
    public static void main(String args[])
    {
    	AzureContentModeration ac = new AzureContentModeration();
    	System.out.println(ac.detectPersonalInfo("Is this a crap email abcdef@abcd.com, phone: 6657789887, IP: 255.255.255.255, 1 Microsoft Way, Redmond, WA 98052"));
    }
    
}