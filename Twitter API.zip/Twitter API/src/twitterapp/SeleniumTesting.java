package twitterapp;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumTesting {
	
	
	public static ArrayList<String> fetchReviews(String url, String num) throws InterruptedException
	{
		try {
		int number=Integer.parseInt(num);
		ArrayList<String> ar = new ArrayList<>();
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		Actions actions = new Actions(driver);
	//		driver.findElementById("twotabsearchtextbox").sendKeys("Dell");
	//		driver.findElement(By.className("nav-input")).click();
	//		driver.findElement(By.className("s-image")).click();
	//		driver.findElement(By.className("a-link-emphasis a-text-bold")).click();
	//		Action sendPageDown = actions.sendKeys(Keys.PAGE_DOWN).build();
	//		sendPageDown.perform();
		//String xpathNoRows="//*[@class='a-section a-spacing-none review-views celwidget']/div";
		//List<WebElement> listTotal = driver.findElements(By.xpath(xpathNoRows));
		int i,k=0;
		int j=1;
		String xpathAllReviews="//*[@class='a-row a-spacing-large']/a";
		driver.findElement(By.xpath(xpathAllReviews)).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		List<WebElement> divs = driver.findElements(By.xpath("//*[@class='a-section a-spacing-none review-views celwidget']/div"));
		int count = divs.size();
		System.out.println(count);
		
		if(count<=10)
		{
			for(i=1; i <=count; i++)
				
			{
			String xpathReviewerName="//*[@class='a-section a-spacing-none review-views celwidget']/div["+i+"]/div/div/div[1]/a/div[2]/span";
			WebElement contentReviewerName = driver.findElement(By.xpath(xpathReviewerName));
			
			String xpathReviewTitle="//*[@class='a-section a-spacing-none review-views celwidget']/div["+i+"]/div/div/div[2]/a[2]/span";
			WebElement contentReviewTitle = driver.findElement(By.xpath(xpathReviewTitle));
			ar.add(contentReviewerName.getText().toString());
			ar.add(contentReviewTitle.getText().toString());
			
			}
			number=0;
			System.out.println(ar);
			return ar;
			}
		else
		{
for(i=1; i <=10; i++)
				
			{
			String xpathReviewerName="//*[@class='a-section a-spacing-none review-views celwidget']/div["+i+"]/div/div/div[1]/a/div[2]/span";
			WebElement contentReviewerName = driver.findElement(By.xpath(xpathReviewerName));
			
			String xpathReviewTitle="//*[@class='a-section a-spacing-none review-views celwidget']/div["+i+"]/div/div/div[2]/a[2]/span";
			WebElement contentReviewTitle = driver.findElement(By.xpath(xpathReviewTitle));
			ar.add(contentReviewerName.getText().toString());
			ar.add(contentReviewTitle.getText().toString());
			
			}
			number=0;
			System.out.println(ar);
			return ar;
		}
		}
		
	catch(Exception e)
	{
		ArrayList<String> ar = new ArrayList<>();
		ar.add("error");
		return ar;
	}
	}
	}

