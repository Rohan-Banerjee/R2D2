package twitterapp;

import java.net.URI;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class SightEngine {

	public ArrayList<String> v_moderate(String v_url, String model_name) {
		// TODO Auto-generated method stub
		HttpClient httpclient = HttpClients.createDefault();
		
		try {
		URIBuilder builder = new URIBuilder("https://api.sightengine.com/1.0/video/check-sync.json?models="+model_name+"&api_user=1908761413&api_secret=p7rkYM77TUZfsfjtEwi4&stream_url="+v_url);
		
		URI uri = builder.build();
		HttpPost request= new HttpPost(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		 
		 if(entity!=null)
		 {
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
			 JSONObject data = object.getJSONObject("data");
			 JSONArray frames = data.getJSONArray("frames");
			 if(model_name.equalsIgnoreCase("wad"))
			 {
				 double weapon,alcohol,drugs;
				 ArrayList <String> ar = new ArrayList<>();
				 int i=0;
				 while(i<frames.length())
				 {
				 JSONObject element = frames.getJSONObject(i);
				 weapon = element.getDouble("weapon");
				 alcohol = element.getDouble("alcohol");
				 drugs = element.getDouble("drugs");
				 
				 if(weapon>0.1)
				 ar.add("Weapon at frame:"+i+"000 is: "+weapon);
				 if(alcohol>0.1)
				 ar.add("Alchohol at frame:"+i+"000 is: "+alcohol);
				 if(drugs>0.1)
				 ar.add("Drugs at frame:"+i+"000 is: "+drugs);
				 
				 i++;
				 }
				 return ar;
			 }
			 else
			 {
				 
			 
			 int i=0;
			 double raw_nudity;
			 double partial_nudity;
			 ArrayList<String> ar = new ArrayList<>();
			 while(i<frames.length())
			 {
			 JSONObject element = frames.getJSONObject(i);
			 JSONObject nudity = element.getJSONObject("nudity");
			 raw_nudity = nudity.getDouble("raw");
			 partial_nudity = nudity.getDouble("partial");
			 
			 if(raw_nudity>0.1)
			 ar.add("Raw Nudity at frame:"+i+"000 is: "+raw_nudity);
			 
			 if(partial_nudity>0.1)
			 ar.add("Partial Nudity at frame:"+i+"000 is: "+partial_nudity);
			 
			 i++;
			 }
			 return ar;
			 }
		}
		}
		catch (Exception e)
		{
			ArrayList<String> ar = new ArrayList<>();
			ar.add("error");
			return ar;
		}
		return null;
		

	
	
}
}
