package twitterapp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.api.client.googleapis.json.GoogleJsonResponseException;

import twitter4j.Status;


@Controller
public class controller {
	ArrayList<String> list = new ArrayList<String>();
	ArrayList<String> list1 = new ArrayList<String>();
	ArrayList<String> list2= new ArrayList<String>();
	ArrayList<String> list3= new ArrayList<String>();
	
	
	ArrayList<String>  ylist1 = new ArrayList<String>();
	ArrayList<String> ylist2= new ArrayList<String>();
	
	List<String> alist1=new ArrayList<String>();
	List<String> alist2=new ArrayList<String>();
	
	@RequestMapping("/gotoLanding")
	public String redirect1(Model model) {
		
		return "landing-new";
	}
	
	@RequestMapping("/gotoSendTweet")
	public String redirect2(Model model) {
		
		return "sendTweet";
	}
	
	@RequestMapping("/gotoDeleteTweet")
	public String redirect3(Model model) {
		
		return "deleteTweet";
	}
	
	@RequestMapping("/gotoTimeline")
	public String redirect4(Model model) {
		
		return "timeline";
	}
	
	@RequestMapping("/gotoSearchQuery")
	public String redirect5(Model model) {
		
		return "searchquery";
	}
	
	
	@RequestMapping("/gotoLandingYoutube")
	public String redirect6(Model model) {
		
		return "landing-youtube";
	}
	
	@RequestMapping("/gotoCommentList")
	public String redirect7(Model model) {
		
		return "commentList";
	}
	@RequestMapping("/gotoLandingSE")
	public String redirect8(Model model) {
		
		return "landingSE";
	}
	@RequestMapping("/gotoModerateVideo")
	public String redirect9(Model model) {
		
		return "moderateVideo";
	}
	@RequestMapping("/gotoLandingSelenium")
	public String redirect10(Model model) {
		
		return "landingSelenium";
	}
	@RequestMapping("/gotoFetchReviews")
	public String redirect11(Model model) {
		
		return "fetchReviews";
	}
	@RequestMapping("/gotoFetchReviewsFlipkart")
	public String redirect12(Model model) {
		
		return "fetchReviewsFlipkart";
	}
	@RequestMapping("/gotoFetchReviewsBestbuy")
	public String redirect13(Model model) {
		
		return "fetchReviewsBestbuy";
	}
	@RequestMapping("/gotomoderateText")
	public String redirect14(Model model) {
		
		return "moderateText";
	}
	@RequestMapping("/gotoEvaluateImage")
	public String redirect15(Model model) {
		
		return "evaluateImage";
	}
	@RequestMapping("/gotodetectFaces")
	public String redirect16(Model model) {
		
		return "detectFaces";
	}
	@RequestMapping("/gotoocr")
	public String redirect17(Model model) {
		
		return "ocr";
	}
	@RequestMapping("/gotodetectLang")
	public String redirect18(Model model) {
		
		return "detectLang";
	}
	@RequestMapping("/gotodetectPersonalInfo")
	public String redirect19(Model model) {
		
		return "detectPersonalInfo";
	}
	@RequestMapping("/gotoFetchNegativeReviews")
	public String redirect20(Model model) {
		
		return "fetchNegativeReviews";
	}
	
	
	@RequestMapping("/sendTweet")
	public String addUsers(@RequestParam String msg, Model model) throws java.lang.Exception {
		if(msg.isEmpty())
		{
			String message = "Can't post an empty tweet!";
			model.addAttribute("message", message);
			return "sendTweet";	
		}
		else
		{
			
		first f = new first();
		f.createTweet(msg);
		String message = "Tweet posted!";
		model.addAttribute("message", message);
		return "sendTweet";
		
		}
	}
	
	@RequestMapping("/deleteTweet")
	public String deleteTweet(@RequestParam String id, Model model) throws java.lang.Exception {
		if(id.isEmpty())
		{
			String message = "No ID provided !";
			model.addAttribute("message", message);
			return "deleteTweet";	
		}
		else
		{
			
			first f = new first();
			long tweet = Long.parseLong(id);
			String s = f.deleteTweet(tweet);
			if(s.equalsIgnoreCase("done"))
					{
				String message = "Deletion successful";
				model.addAttribute("message", message);
				return "deleteTweet";
					}
			else
			{
			String message = "Something went wrong. Try again later!";
			model.addAttribute("message", message);
			return "deleteTweet";
		
			}
		}
	}
	
	@RequestMapping("/generateTimeline")
	public String generateTimeline(Model model) throws java.lang.Exception {
		first f = new first();
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list = f.getTimeLine();
		int i=0;
		if(list.get(0).toString().equalsIgnoreCase("error"))
		{
			model.addAttribute("error","Oops something went wrong. Please try again later!");
			return "searchResult";
		}
		while(i<list.size())
		{
			list1.add(list.get(i));
			list2.add(list.get(i+1));
			list3.add(list.get(i+2)+":small");
			i=i+3;
		}
		model.addAttribute("message",list1);
		model.addAttribute("message1", list2);
		model.addAttribute("message2", list3);	
		
		return "searchResult";
	}
		
		
		@RequestMapping("/search")
		public String search(Model model, String query) throws java.lang.Exception {
			if(query.isEmpty())
			{
				model.addAttribute("message", "Cannot search an empty string! Please enter a valid query..");
				return "searchquery";
			}
			
			list.clear();
			list1.clear();
			list2.clear();
			list3.clear();
			first f = new first();
//			List<String> list=new ArrayList<String>(50);
//			List<String> list1=new ArrayList<String>(15);
//			List<String> list2=new ArrayList<String>(15);
//			List<String> list3=new ArrayList<String>(15);
			list = f.searchtweets(query);
			int i=0;
			if(list.get(0).equalsIgnoreCase("error"))
			{
			model.addAttribute("message", "Oh! Something went wrong :( . Please search a valid string.");
		    return "searchquery";
			}
			while(i<list.size())
			{
				list1.add(list.get(i));
				list2.add(list.get(i+1));
				list3.add(list.get(i+2)+":small");
				i=i+3;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			model.addAttribute("message2", list3);
			return "searchResult";
		
		
	}
		
		@RequestMapping("/new")
		public String new1(Model model,String vid,String num) throws GoogleJsonResponseException, GeneralSecurityException, IOException {
			if(vid.isEmpty() || num.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "commentList";
			}
		
			int number = Integer.parseInt(num);
			if(number > 100)
			{
				model.addAttribute("message","Cannot fetch more than 100 comments.");
				return "commentList";
			}
			else if(number<0)
			{
				model.addAttribute("message","Number of comments cannot be below 0.");
				return "commentList";
			}
			ApiExample ap = new ApiExample();
			ArrayList<String> ar = new ArrayList<String>();
			ArrayList<String> list1 = new ArrayList<String>();
			ArrayList<String> list2 = new ArrayList<String>();
			ar =  ap.fetchCommentsUsingVid(vid, number);
			if(ar.size()==1)
			{
				if(ar.get(0).equalsIgnoreCase("error"))
				{
				model.addAttribute("message", "Oh! Your video wasn't found. Please enter a valid URL.");
			    return "commentList";
				}
			}
			int i=0;
			while(i<ar.size())
			{
				list1.add(ar.get(i));
				list2.add(ar.get(i+1));
				i=i+2;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			ylist1=list1;
			ylist2=list2;
			return "commentList2";
		}
		
		@RequestMapping("/moderateVideo")
		public String moderateVideo(String model_name, String v_url, Model model) throws java.lang.Exception {
			String model_name1 = model_name.trim();
			if(v_url.isEmpty() || model_name.isEmpty())
			{
				String message = "Empty String";
				model.addAttribute("message", message);
				return "moderateVideo";	
			}
			else if(!(model_name1.equalsIgnoreCase("wad") || model_name1.equalsIgnoreCase("nudity")))
			{
				String message = "Enter a valid model name. Enter \"nudity\" to detect Nudity. Enter \"wad\" for Weapon alcohol and drugs ";
				model.addAttribute("message", message);
				return "moderateVideo";	
			}
			else
			{
			ArrayList<String> ar = new ArrayList<>();
			SightEngine se = new SightEngine();
			String v_url1 = v_url.trim();
			ar = se.v_moderate(v_url1,model_name1);
			if(ar.size()==1)
			{
				if(ar.get(0).equalsIgnoreCase("error"))
				model.addAttribute("message", "Cannot fetch the Video from URL. Enter valid path..!");
				return "moderateVideo";
			}
			model.addAttribute("v_url",v_url1);
			model.addAttribute("frames", ar);
			return "moderateVideo";
			}
		}
		
		@RequestMapping("/fetchReviews")
		public String fetchReviews(Model model, String url, String num) throws java.lang.Exception {
			if(url.isEmpty() || num.isEmpty())
			{
				model.addAttribute("message", "Fields Empty");
				return "fetchReviews";
			}
			alist1.clear();
			alist2.clear();
			int number= Integer.parseInt(num);
			ArrayList<String> ar = new ArrayList<String>();
			SeleniumJsoup sj = new SeleniumJsoup();
			ar= sj.fetchAmazonReviews(url,number);
			
			int i=0;
			if(ar.get(0).equalsIgnoreCase("error"))
			{
				model.addAttribute("message", "Cannot find the specified product. Check your URL");
				return "fetchReviews";
			}
			while(i<ar.size()-1)
			{
				alist1.add(ar.get(i));
				alist2.add(ar.get(i+1));
				i=i+2;
			}
			int count = Integer.parseInt(ar.get(ar.size()-1).toString());
			if(count==number)
			{	
				model.addAttribute("nos","Reviews Fetched: "+count);
				model.addAttribute("message",alist1);
				model.addAttribute("message1", alist2);
				return "searchResultSeleniumAmazon";
			}
			
			model.addAttribute("nos","Could only fetch  "+count+" reviews.");
			model.addAttribute("message",alist1);
			model.addAttribute("message1", alist2);
			return "searchResultSeleniumAmazon";
		}
		
		@RequestMapping("/fetchReviewsFlipkart")
		public String fetchReviewsFlipkart(Model model, String url) throws java.lang.Exception {
			String num="0";
			if(url.isEmpty())
			{
				model.addAttribute("message", "Please enter a valid URL");
				return "fetchReviewsFlipkart";
			}
			SeleniumFlipkart sf = new SeleniumFlipkart();
			ArrayList<String> ar = new ArrayList<String>();
			ar= sf.fetchReviews(url,num);
			List<String> list1=new ArrayList<String>();
			List<String> list2=new ArrayList<String>();
			int i=0;
			if(ar.get(0).equalsIgnoreCase("error"))
			{
				model.addAttribute("message", "Cannot find the specified product. Check your URL");
				return "fetchReviewsFlipkart";
			}
			while(i<ar.size())
			{
				list1.add(ar.get(i));
				list2.add(ar.get(i+1));
				i=i+2;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			return "searchResultSeleniumFlipkart";
		}
		
		@RequestMapping("/fetchReviewsBestbuy")
		public String fetchReviewsBestbuy(Model model, String url) throws java.lang.Exception {
			String num="0";
			if(url.isEmpty())
			{
				model.addAttribute("message", "Please enter a valid URL");
				return "fetchReviewsBestbuy";
			}
			SeleniumBestbuy se = new SeleniumBestbuy();
			ArrayList<String> ar = new ArrayList<String>();
			ar= se.fetchReviews(url,num);
			List<String> list1=new ArrayList<String>();
			List<String> list2=new ArrayList<String>();
			int i=0;
			if(ar.get(0).equalsIgnoreCase("error"))
			{
				model.addAttribute("message", "Cannot find the specified product. Check your URL");
				return "fetchReviewsBestbuy";
			}
			while(i<ar.size())
			{
				list1.add(ar.get(i));
				list2.add(ar.get(i+1));
				i=i+2;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			return "searchResultSeleniumBestbuy";
		}
		
		@RequestMapping("/moderateText")
		public String moderatetext(Model model, String msg) throws java.lang.Exception {
			if(msg.isEmpty())
			{
				model.addAttribute("message", "Empty String");
				return "moderateText";
			}
			String text = msg;
			msg = msg.replaceAll("\\s", "+");
			TextModerate tm = new TextModerate();
			ArrayList<String> s= tm.moderateText(msg);
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> freq = new ArrayList<>();
			
			String original = s.get(0);
			if(original.equalsIgnoreCase("|empty|"))
			{
				words.add("No Bad Words Found");
				freq.add("-");
				model.addAttribute("header1","Bad Words");
				model.addAttribute("header2","Frequency");
				model.addAttribute("freq",freq);
				model.addAttribute("words",words);
				model.addAttribute("message", "No Bad words found !");
				model.addAttribute("original","Original String: "+text);
				model.addAttribute("review", "Review Recommended: NO");
				return "moderateText";
			}
			if(original.equalsIgnoreCase("no internet"))
			{
				model.addAttribute("message", "Something went Wrong. Please try again later!");
				return "moderateText";
			}
			String clean = s.get(1);
			int i=2;
			while(i<s.size())
			{
				words.add(s.get(i));
				freq.add(s.get(i+1));
				i+=2;
			}
			model.addAttribute("header1","Bad Words");
			model.addAttribute("header2","Frequency");
			model.addAttribute("original", "Original String: "+clean);
			model.addAttribute("clean", "String after moderating: "+original);
			model.addAttribute("words",words);
			model.addAttribute("freq",freq);
			model.addAttribute("review", "Review Recommended: YES");
			return "moderateText";
		}
			
		@RequestMapping("/moderateTwitterText")
		public String moderateTwittertext(Model model, String content){
		
			try {
			String msg = content;
			content = content.replaceAll("\\s", "+");
			TextModerate tm = new TextModerate();
			ArrayList<String> ar = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> freq = new ArrayList<>();
			ar=tm.moderateText(content);
			
			PerspectiveAPI pa = new PerspectiveAPI();
			double value= pa.calToxicity(content);
			String original = ar.get(0);
			if(original.equalsIgnoreCase("|empty|"))
			{
				
				words.add("No Bad Words Found");
				freq.add("-");
				model.addAttribute("toxicity","Toxicity found in the content: "+value+"%");
				model.addAttribute("header1", "Bad Words");
				model.addAttribute("header2", "Frequency");
				model.addAttribute("review", "Review Recommended: NO");
				model.addAttribute("words",words);
				model.addAttribute("freq", freq);
				model.addAttribute("message",	list1);
				model.addAttribute("message1", list2);
				model.addAttribute("message2", list3);
				model.addAttribute("original", "Original String: "+msg);
				return "searchResult";
			}
			String clean = ar.get(1);
			int i=2;
			while(i<ar.size())
			{
				words.add(ar.get(i));
				freq.add(ar.get(i+1));
				i+=2;
			}		
			
			model.addAttribute("toxicity","Toxicity found in the content: "+value+"%");
			model.addAttribute("original", "Original String: "+clean);
			model.addAttribute("clean", "String after moderating: "+original);
			model.addAttribute("header1", "Bad Words");
			model.addAttribute("header2", "Frequency");
			model.addAttribute("words",words);
			model.addAttribute("freq",freq);
			model.addAttribute("review", "Review Recommended: YES");
			model.addAttribute("message",	list1);
			model.addAttribute("message1", list2);
			model.addAttribute("message2", list3);		
			return "searchResult";
			}
			catch(Exception e)
			{
				model.addAttribute("notice","Please select the Radio button to Moderate Content.");
				model.addAttribute("message",	list1);
				model.addAttribute("message1", list2);
				model.addAttribute("message2", list3);
				return "searchResult";
			}
		}
	
		@RequestMapping("/moderateYoutubeText")
		public String moderateYoutubetext(Model model, String content){
			try {
			if(content.isEmpty())
			{
				model.addAttribute("notice","Empty String");
				return "commentList2";
			}
			String msg = content;
			content = content.replaceAll("\\s", "+");
			TextModerate tm = new TextModerate();
			ArrayList<String> ar = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> freq = new ArrayList<>();
			ar=tm.moderateText(content);
			PerspectiveAPI pa = new PerspectiveAPI();
			double value = pa.calToxicity(content);
			String original = ar.get(0);
			if(original.equalsIgnoreCase("|empty|"))
			{
				
				words.add("No Bad Words Found");
				freq.add("-");
				model.addAttribute("toxicity","Toxicity found in the content: "+value+"%");
				model.addAttribute("words",words);
				model.addAttribute("freq",freq);
				model.addAttribute("header1", "Bad Words");
				model.addAttribute("header2", "Frequency");
				model.addAttribute("review", "Review Recommended: NO");
				model.addAttribute("message",	ylist1);
				model.addAttribute("message1", ylist2);
				model.addAttribute("original", "Original String: "+msg);
				return "commentList2";
			}
			String clean = ar.get(1);
			int i=2;
			while(i<ar.size())
			{
				words.add(ar.get(i));
				freq.add(ar.get(i+1));
				i+=2;
			}	
			model.addAttribute("toxicity","Toxicity found in the content: "+value+"%");
			model.addAttribute("original", "Original String: "+clean);
			model.addAttribute("clean", "String after moderating: "+original);
			model.addAttribute("words",words);
			model.addAttribute("freq",freq);
			model.addAttribute("header1", "Bad Words");
			model.addAttribute("header2", "Frequency");
			model.addAttribute("review", "Review Recommended: YES");
			model.addAttribute("message",	ylist1);
			model.addAttribute("message1", ylist2);	
			return "commentList2";
			}
			catch(Exception e)
			{
				model.addAttribute("notice","Select a Radio Button to Moderate Content.");
				model.addAttribute("message",	ylist1);
				model.addAttribute("message1", ylist2);	
				return "commentList2";
			}
		}
		
		@RequestMapping("/moderateAmazonText")
		public String moderateAmazontext(Model model, String content) {
			try {
			if(content.isEmpty())
			{
				model.addAttribute("notice","Empty String");
				return "fetchReviews";
			}
			String msg = content;
			content = content.replaceAll("\\s", "+");
			TextModerate tm = new TextModerate();
			ArrayList<String> ar = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> freq = new ArrayList<>();
			ar=tm.moderateText(content);
			
			PerspectiveAPI pa = new PerspectiveAPI();
			double toxicity= pa.calToxicity(content);
			System.out.println(toxicity);
			String original = ar.get(0);
			if(original.equalsIgnoreCase("|empty|"))
			{
				words.add("No Bad Words Found");
				freq.add("-");
				model.addAttribute("toxicity","Toxicity found in the review: "+toxicity+"%");
				model.addAttribute("words",words);
				model.addAttribute("freq",freq);
				model.addAttribute("header1","Bad Words Found");
				model.addAttribute("header2","Frequency");
				model.addAttribute("review", "Review Recommended: NO");
				model.addAttribute("message",	alist1);
				model.addAttribute("message1", alist2);
				model.addAttribute("original", "Original String: "+msg);
				return "searchResultSeleniumAmazon";
			}
			String clean = ar.get(1);
			int i=2;
			while(i<ar.size())
			{
				words.add(ar.get(i));
				freq.add(ar.get(i+1));
				i+=2;
			}	
			model.addAttribute("toxicity","Toxicity found in the review: "+toxicity+"%");
			model.addAttribute("header1","Bad Words Found");
			model.addAttribute("header2","Frequency");
			model.addAttribute("original", "Original String: "+clean);
			model.addAttribute("clean", "String after moderating: "+original);
			model.addAttribute("words",words);
			model.addAttribute("freq",freq);
			model.addAttribute("review", "Review Recommended: YES");
			model.addAttribute("message",	alist1);
			model.addAttribute("message1", alist2);	
			return "searchResultSeleniumAmazon";
			}
			catch(Exception e)
			{
				model.addAttribute("notice","Please select a Radio Button to Moderate Content.");
				model.addAttribute("message",	alist1);
				model.addAttribute("message1", alist2);
				return "searchResultSeleniumAmazon";
			}
		}
		
		@RequestMapping("/evaluateImage")
		public String evaluateImageMethod(Model model,String url) {
			if(url.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "evaluateImage";
			}
			AzureContentModeration acm= new AzureContentModeration();
			ArrayList<String> ar = new ArrayList<String>();
			ar =  acm.evaluateImage(url);
			if(ar.get(0).equalsIgnoreCase("error"))
			{
				model.addAttribute("message","Something went wrong! Please check your URL");
				return "evaluateImage";
			}
			model.addAttribute("adultScore",ar.get(0).toString());
			model.addAttribute("racyScore",ar.get(2).toString());
			model.addAttribute("isAdult",ar.get(1).toString());
			model.addAttribute("isRacy", ar.get(3).toString());
			return "evaluateImage";
		}
	
		@RequestMapping("/detectFaces")
		public String detectFaces(Model model,String url) {
			if(url.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "detectFaces";
			}
			AzureContentModeration acm= new AzureContentModeration();
			ArrayList<Integer> ar = new ArrayList<Integer>();
			ArrayList<String> faceinfo = new ArrayList<String>();
			ar =  acm.findFaces(url);
			System.out.println(ar.size());
			if(ar.get(0)==0)
			{
				model.addAttribute("count",0);
				return "detectFaces";
			}
			else if(ar.get(0)==-1)
			{
				model.addAttribute("message","Something went wrong! Please check your URL");
				return "detectFaces";
			}
			else
			{
				int i=1,j=1;
				while(i<(ar.size()))
				{
					faceinfo.add("Face No: "+j+" Left "+Integer.toString(ar.get(i)));
					faceinfo.add("Face No: "+j+" Right "+Integer.toString(ar.get(i+1)));
					faceinfo.add("Face No: "+j+" Top "+Integer.toString(ar.get(i+2)));
					faceinfo.add("Face No: "+j+" Bottom "+Integer.toString(ar.get(i+3)));
					faceinfo.add("--------------------------------------------------");
					i+=4;
					j+=1;
					}
			}
			model.addAttribute("count",ar.get(0).toString());
			model.addAttribute("faceinfo",faceinfo);
			return "detectFaces";
		}
		@RequestMapping("/ocr")
		public String ocr(Model model,String url) {
			if(url.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "ocr";
			}
			AzureContentModeration acm= new AzureContentModeration();
			String s =  acm.ocr(url);
			System.out.println(s);
			if(s.equalsIgnoreCase("error"))
			{
				model.addAttribute("message","Something went wrong. Please check your URL");
				return "ocr";
			}
			model.addAttribute("string",s);
			return "ocr";
		}
		@RequestMapping("/detectLang")
		public String detectLang(Model model,String text) {
			if(text.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "detectLang";
			}
			AzureContentModeration acm= new AzureContentModeration();
			String s =  acm.detectLanguage(text);
			if(s.equalsIgnoreCase("|||error|||"))
			{
				model.addAttribute("lang","Error! Please try again later!");
				return "detectLang";
			}
			if(s.equalsIgnoreCase("eng"))
			{
				model.addAttribute("lang","Language Found: English");
				return "detectLang";
			}
			else if(s.equalsIgnoreCase("fra"))
			{
				model.addAttribute("lang","Language Found: French");
				return "detectLang";
			}
			else if(s.equalsIgnoreCase("spa"))
			{
				model.addAttribute("lang","Language Found: Spanish");
				return "detectLang";
			}
			else if(s.equalsIgnoreCase("ita"))
			{
				model.addAttribute("lang","Language Found: Italian");
				return "detectLang";
			}
			model.addAttribute("lang","Language Found: "+s);
			return "detectLang";
		}
		@RequestMapping("/detectPersonalInfo")
		public String detectPersonalInfo(Model model,String text) {
			if(text.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "detectPersonalInfo";
			}
			AzureContentModeration acm= new AzureContentModeration();
			ArrayList<String> ar = new ArrayList();
			ar =  acm.detectPersonalInfo(text);
			if(ar.get(0).toString().equalsIgnoreCase("error"))
			{
				model.addAttribute("info","Error occured ! Please try again later.");
				return "detectPersonalInfo";	
			}
			model.addAttribute("info",ar);
			return "detectPersonalInfo";
		}
		@RequestMapping("/fetchNegativeReviews")
		public String fetchNegativeReviews(Model model, String url, String num){
			if(url.isEmpty() || num.isEmpty())
			{
				model.addAttribute("message", "Fields Empty");
				return "fetchReviews";
			}
			alist1.clear();
			alist2.clear();
			int number= Integer.parseInt(num);
			ArrayList<String> ar = new ArrayList<String>();
			SeleniumJsoup sj = new SeleniumJsoup();
			ar= sj.fetchCriticalReviews(url, number);
			
			int i=0;
			if(ar.get(0).equalsIgnoreCase("error"))
			{
				model.addAttribute("message", "Cannot find the specified product. Check your URL");
				return "fetchReviews";
			}
			while(i<ar.size()-1)
			{
				alist1.add(ar.get(i));
				alist2.add(ar.get(i+1));
				i=i+2;
			}
			int count = Integer.parseInt(ar.get(ar.size()-1).toString());
			if(count==number)
			{
			
				model.addAttribute("nos","Reviews Fetched: "+count);
				model.addAttribute("message",alist1);
				model.addAttribute("message1", alist2);
				return "searchResultSeleniumAmazon";
			}
			
			model.addAttribute("nos","Could only fetch  "+count+" reviews.");
			model.addAttribute("message",alist1);
			model.addAttribute("message1", alist2);
			return "searchResultSeleniumAmazon";
		}
		
}
