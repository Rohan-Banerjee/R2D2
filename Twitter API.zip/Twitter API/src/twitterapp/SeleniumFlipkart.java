package twitterapp;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumFlipkart {

	public static ArrayList<String> fetchReviews(String url, String num) throws InterruptedException {
		try {
		int number = Integer.parseInt(num);
		ArrayList<String> ar = new ArrayList<>();
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		Actions actions = new Actions(driver);
		try {
			int i, j = 0;
			String xpathAllReviews = "//*[@class='col _39LH-M']/a";
			if(driver.findElements(By.xpath(xpathAllReviews)).size() != 0)
			{
				WebDriverWait wait=new WebDriverWait(driver, 20);
				WebElement button;
				driver.findElement(By.xpath(xpathAllReviews)).click();
				
				for (i = 3; i <= 12; i++)

				{
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					String xpathReviewerName = "//*[@class='ooJZfD _2oZ8XT col-9-12']/div[" + i
							+ "]/div/div/div/div[@class='row _2pclJg']/div[1]/p";
					WebElement contentReviewerName = driver.findElement(By.xpath(xpathReviewerName));

					String xpathReviewTitle = "//*[@class='ooJZfD _2oZ8XT col-9-12']/div[" + i + "]/div/div/div/div[1]/p";
					WebElement contentReviewTitle = driver.findElement(By.xpath(xpathReviewTitle));
					ar.add(contentReviewerName.getText().toString());
					ar.add(contentReviewTitle.getText().toString());
					
					

				}
				String next = "//a[@class='_3fVaIS']"; 
				button= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(next)));
				button.click();
				//driver.findElementByXPath(next).click();
				//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				j++;
				return ar;
			
			}
			else {
				List<WebElement> divs = driver.findElements(By.xpath("//*[@class='_2aFisS _3cycCZ']/div"));
				int count = divs.size();
				for (i = 1; i <= count; i++)

				{
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					String xpathReviewerName = "//*[@class='_2aFisS _3cycCZ']/div[" + i
							+ "]/div/div/div[@class='row _2pclJg']/div[1]/p";
					WebElement contentReviewerName = driver.findElement(By.xpath(xpathReviewerName));

					String xpathReviewTitle = "//*[@class='_2aFisS _3cycCZ']/div[" + i + "]/div/div/div[1]/div/div/div[2]";
					WebElement contentReviewTitle = driver.findElement(By.xpath(xpathReviewTitle));
					ar.add(contentReviewerName.getText().toString());
					ar.add(contentReviewTitle.getText().toString());

				}

				return ar;
				

			}
		} 
		catch(org.openqa.selenium.StaleElementReferenceException ex)
		{
			String next = "//a[@class='_3fVaIS']"; 
		    WebElement button = driver.findElement(By.xpath(next));
		    button.click();
		}
		return ar;
		}
		catch(Exception e)
		{
			ArrayList<String> ar = new ArrayList<>();
			ar.add("error");
			return ar;
		}

	}
	

}
