package twitterapp;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumBestbuy {

	public static ArrayList<String> fetchReviews(String url, String num) throws InterruptedException {
		try {
			int number = Integer.parseInt(num);
			ArrayList<String> ar = new ArrayList<>();
			System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");
			ChromeDriver driver = new ChromeDriver();
			driver.get(url + "&intl=nosplash");
			driver.manage().window().maximize();
			Actions actions = new Actions(driver);
			// Action cancel = actions.sendKeys(Keys.PAGE_DOWN).build();
			// cancel.perform();
			System.out.println("1st");
			// String country = "//*[@class='country-selection']/a[2]";
			// driver.findElementByXPath(country).click();

			int i, j = 0;
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String xpathAllReviews = "/html/body/div[4]/main/div[1]/div[6]/div/div[1]/div[3]/div/div/div[1]/button";
			driver.findElement(By.xpath(xpathAllReviews)).click();
			System.out.println("2nd");
			for (i = 1; i <= 8; i++)

			{

				String xpathReviewerName = "//*[@class='reviews-list']/li[" + i + "]/div/div[1]/div/span";
				WebElement contentReviewerName = driver.findElement(By.xpath(xpathReviewerName));

				String xpathReviewTitle = "//*[@class='reviews-list']/li[" + i + "]/div/div[2]/div[4]/h4";
				WebElement contentReviewTitle = driver.findElement(By.xpath(xpathReviewTitle));
				ar.add(contentReviewerName.getText().toString());
				ar.add(contentReviewTitle.getText().toString());

			}
			return ar;

		} catch (Exception e) {
			e.printStackTrace();
			ArrayList<String> ar = new ArrayList<>();
			ar.add("error");
			return ar;
		}
	}
}
