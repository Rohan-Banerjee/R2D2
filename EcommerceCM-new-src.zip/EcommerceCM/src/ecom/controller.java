package ecom;

import java.io.IOException;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class controller {
	ArrayList<String> list = new ArrayList<String>();
	ArrayList<String> list1 = new ArrayList<String>();
	ArrayList<String> list2= new ArrayList<String>();
	ArrayList<String> list3= new ArrayList<String>();
	
	
	ArrayList<String>  ylist1 = new ArrayList<String>();
	ArrayList<String> ylist2= new ArrayList<String>();
	
	ArrayList<String> alist1=new ArrayList<String>();
	ArrayList<String> alist2=new ArrayList<String>();
	
	ArrayList<String> flist1 = new ArrayList<String>();
	ArrayList<String> flist2 = new ArrayList<String>();
	
	@RequestMapping("/gotoLanding")
	public String redirect1(Model model) {
		
		return "index";
	}
	
	@RequestMapping("/gotoCommentList")
	public String redirect7(Model model) {
		
		return "commentList";
	}
	@RequestMapping("/gotoFetchReviews")
	public String redirect11(Model model) {
		
		return "fetchReviews";
	}
	
	@RequestMapping("/gotoFetchNegativeReviews")
	public String redirect20(Model model) {
		
		return "fetchNegativeReviews";
	}
	@RequestMapping("/checkLogin")
	public String checkLogin(@RequestParam String email,String pass, Model model) throws java.lang.Exception {
		
		if(email.toString().equalsIgnoreCase("admin")&& pass.toString().equalsIgnoreCase("admin"))
		{
			model.addAttribute("user", email);
			return "home";
		}
		else
		{
			return "tryAgain";
		}
	}
	@RequestMapping("/createAmazonGraph")
	public String createAmazonGraph(Model model) throws IOException {
		
		
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		//response = db.getFbPostsfromDB();
		response =db.readcontentfromJSON();
		//response = docs;
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				String tox = ob.getString("Toxicity");
				System.out.println(tox);
				tox_val= Double.parseDouble(tox);
				
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("feedback"))
				{
					feedback++;
				}
				else
				{
					spam++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", bored);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data1.put("category", "Excited");
		emotion_data1.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		
		System.out.println("Emotion"+emotion);

		return "facebookCharts";
	}
	
	@RequestMapping("/fetchReviews")
		public String fetchReviews(Model model, String url) throws java.lang.Exception {
		System.out.println(url);
		String num = "5";
		if(url.isEmpty() || num.isEmpty())
			{
				model.addAttribute("message", "Fields Empty");
				return "fetchReviews";
			}
			alist1.clear();
			alist2.clear();
			int number= Integer.parseInt(num);
			ArrayList<String> ar = new ArrayList<String>();
			SeleniumJsoup sj = new SeleniumJsoup();
			ar= sj.fetchAmazonReviews(url,number); 
			
			int i=0;
			if(ar.get(0).equalsIgnoreCase("error"))
			{
				model.addAttribute("error", "Cannot find the specified product. Check your URL");
				return "commentList";
			}
			while(i<ar.size()-1)
			{
				alist1.add(ar.get(i));
				alist2.add(ar.get(i+1));
				i=i+2;
			}
			int count = Integer.parseInt(ar.get(ar.size()-1).toString());
			if(count==number)
			{	
				model.addAttribute("nos","Reviews Fetched: "+count);
				model.addAttribute("message",alist1);
				model.addAttribute("message1", alist2);
				moderateAmazontext(model, alist2);
				return "commentList";
			}
			
			model.addAttribute("nos","Could only fetch  "+count+" reviews.");
			model.addAttribute("message",alist1);
			model.addAttribute("message1", alist2);
			System.out.println("went till here");
			moderateAmazontext(model, alist2);
			return "commentList";
		}
		
		@RequestMapping("/moderateAmazonText")
		public String moderateAmazontext(Model model, ArrayList<String> list1) throws Exception {
			ArrayList<String> child = new ArrayList<String>();
			ArrayList<String> intents = new ArrayList<>();
			ArrayList<String> reviews = new ArrayList<>();
			ArrayList<String> badWords = new ArrayList<>();
			ArrayList <ArrayList<String>> moderatedText= new ArrayList<>(); 
			int i = 0;
			while(i<5)
			{
				//identifying bad words
				String n = list1.get(i).toString();
				SightEngine se = new SightEngine();
				n = n.replaceAll("\\s", "+");
				n= n.replaceAll("[^a-zA-Z0-9]", "+"); 
				child = se.textModerate(n, "en");
				if(child.get(0).toString().equalsIgnoreCase("|empty|"))
				{
					child.add(0, "No Bad words");
				}
				moderatedText.add(child);
				
				//idetifying sentiments
				ParallelDots pd = new ParallelDots();
				String intent = pd.intentAnalysis(list1.get(i).toString());
				intents.add(intent);
				
				System.out.println("went till here1");
				System.out.println("child="+child);
				if(!(child.get(0).toString().equalsIgnoreCase("No Bad Words") && intent.toString().equalsIgnoreCase("Complaint")))	
				{
					
					String review = "No";
					reviews.add(review);
				}
				else
				{
					String review ="Yes";
					reviews.add(review);
				}
				badWords.add(child.get(0).toString());
			i++;
			}
			
			
				model.addAttribute("message",	alist1);
				model.addAttribute("message1", alist2);
				model.addAttribute("moderate",moderatedText);
				model.addAttribute("bad", badWords);
				
				model.addAttribute("intent", intents);
				model.addAttribute("review", reviews);
				return "commentList";
			}
		
		@RequestMapping("/fetchNegativeReviews")
		public String fetchNegativeReviews(Model model, String url) throws Exception{
			System.out.println(url);
			String num = "5";
			if(url.isEmpty() || num.isEmpty())
				{
					model.addAttribute("message", "Fields Empty");
					return "fetchNegativeReviews";
				}
				alist1.clear();
				alist2.clear();
				int number= Integer.parseInt(num);
				ArrayList<String> ar = new ArrayList<String>();
				SeleniumJsoup sj = new SeleniumJsoup();
				ar= sj.fetchCriticalReviews(url, number);
				
				int i=0;
				if(ar.get(0).equalsIgnoreCase("error"))
				{
					model.addAttribute("error", "Cannot find the specified product. Check your URL");
					return "fetchNegativeReviews";
				}
				while(i<ar.size()-1)
				{
					alist1.add(ar.get(i));
					alist2.add(ar.get(i+1));
					i=i+2;
				}
				int count = Integer.parseInt(ar.get(ar.size()-1).toString());
				if(count==number)
				{	
					model.addAttribute("nos","Reviews Fetched: "+count);
					model.addAttribute("message",alist1);
					model.addAttribute("message1", alist2);
					moderateAmazontext(model, alist2);
					return "fetchNegativeReviews";
				}
				
				model.addAttribute("nos","Could only fetch  "+count+" reviews.");
				model.addAttribute("message",alist1);
				model.addAttribute("message1", alist2);
				System.out.println("went till here");
				moderateAmazontext(model, alist2);
				return "fetchNegativeReviews";
			}

		

}
