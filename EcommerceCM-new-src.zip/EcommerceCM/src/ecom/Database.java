package ecom;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

public class Database {
	
	public JSONArray readcontentfromJSON()
	{
		JSONArray response = null ;
		JSONParser parser = new JSONParser();
	      try {
	         Object obj = parser.parse(new FileReader("C:\\json/dummy-data.json"));
	         org.json.simple.JSONArray ar = (org.json.simple.JSONArray)obj;
	         String s = ar.toString();
	         response = new JSONArray(s);
	        
	      } catch(Exception e) {
	         e.printStackTrace();
	      }
		return response;
	}
	
	public JSONArray readImagesfromJSON()
	{
		JSONArray response = null ;
		JSONParser parser = new JSONParser();
	      try {
	         Object obj = parser.parse(new FileReader("C:\\json/dummy-images-data.json"));
	         org.json.simple.JSONArray ar = (org.json.simple.JSONArray)obj;
	         String s = ar.toString();
	         response = new JSONArray(s);
	        
	      } catch(Exception e) {
	         e.printStackTrace();
	      }
		return response;
	}
	
	
	
	public JSONArray fetchDataUsingFilterPosts(String sentiment, String intent) throws ParseException, FileNotFoundException, IOException, org.json.simple.parser.ParseException
	{
	
		 JSONArray array = new JSONArray();
	      int range = 0;
	      
	      JSONArray response = null ;
     	  JSONParser parser = new JSONParser();
	      
			Object obj = parser.parse(new FileReader("C:\\json/dummy-data.json"));
	        org.json.simple.JSONArray ar = (org.json.simple.JSONArray)obj;
	        String s = ar.toString();
	        response = new JSONArray(s);
	        int i =0;
	        while(i<response.length())
	          {
	        	  JSONObject j = response.getJSONObject(i);
	        	  String senti = j.getString("Sentiment");
	        	  String inte = j.getString("Intent");
	            	   
	            	   if(senti.toString().equalsIgnoreCase(sentiment) || inte.toString().equalsIgnoreCase(intent))
	            	   {
	            		   JSONObject data = new JSONObject();
	            	   
		            	   data.put("Name", j.getString("Name"));
		            	   data.put("Content", j.getString("Content"));
		            	   data.put("Toxicity", j.getString("Toxicity"));
		            	   data.put("Intent", j.getString("Intent"));
		            	   data.put("Emotion", j.getString("Emotion"));
		            	   data.put("Sentiment", j.getString("Sentiment"));
		            	   data.put("Review", j.getString("Review"));
	            	   
		               array.put(data);
	            	}
	            	   i++;
	               }
	 
				return array;
	}
	
//	public JSONArray fetchDataUsingFilterImages(String sentiment, String intent) throws ParseException, FileNotFoundException, IOException, org.json.simple.parser.ParseException
//	{
//	
//		 JSONArray array = new JSONArray();
//	      int range = 0;
//	      
//	      JSONArray response = null ;
//     	  JSONParser parser = new JSONParser();
//	      
//			Object obj = parser.parse(new FileReader("C:\\json/dummy-data.json"));
//	        org.json.simple.JSONArray ar = (org.json.simple.JSONArray)obj;
//	        String s = ar.toString();
//	        response = new JSONArray(s);
//	        int i =0;
//	        while(i<response.length())
//	          {
//	        	  JSONObject j = response.getJSONObject(i);
//	        	  String senti = j.getString("Sentiment");
//	        	  String inte = j.getString("Intent");
//	            	   
//	            	   if(senti.toString().equalsIgnoreCase(sentiment) || inte.toString().equalsIgnoreCase(intent))
//	            	   {
//	            		   JSONObject data = new JSONObject();
//	            	   
//	            		   data.put("url", j.getString("url"));
//		            	   data.put("review", j.getString("review"));
//		            	   data.put("category", j.getString("category"));
//		            	   data.put("date", j.getString("date"));
//		            	   
//	            	   
//		               array.put(data);
//	            	}
//	            	   i++;
//	               }
//	 
//				return array;
//	}
	
	
	
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		Database d = new Database();
		//System.out.println(d.getRange("24/7/2020", "24/7/2020"));
		
	}

}
