package dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

import connection.connection;

public class product {

	public int saveProduct(String pname, String pdesc, String price)
	{
		try {
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("product");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("pname", pname);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{	
				//pname already present
				cursor.close();
				return 0;
			}
			else
			{
				cursor.close();
			BasicDBObject document = new BasicDBObject();
			document.put("pname", pname);
			document.put("pdesc", pdesc);
			document.put("price", price);
			collection.insert(document);
			return 1;
		}
		}
			catch(Exception e)
			{
				System.out.print(e);
			}
		
			return 0;	

	}
	
	
	public String getDescription(String pname)
	{
		String dbpdesc="";
		try
		{
			
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("product");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("pname", pname);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{
				BasicDBObject dbo= new BasicDBObject();
				dbo = (BasicDBObject) cursor.next();
				dbpdesc = dbo.getString("pdesc");
				
				return dbpdesc ; 
			}
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	

return dbpdesc;
}
	public String getPrice(String pname)
	{
		String dbprice="";
		try
		{
			
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("product");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("pname", pname);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{
				BasicDBObject dbo= new BasicDBObject();
				dbo = (BasicDBObject) cursor.next();
				dbprice = dbo.getString("price");
				
				return dbprice ; 
			}
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	

return dbprice;
}
	
	public int updateProduct(String pname, String pdesc, String price)
	{
		try {
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("product");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("pname", pname);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{	
				//present
				BasicDBObject document = new BasicDBObject();
				BasicDBObject query = new BasicDBObject();
				query.put("pname", pname);
				 
				BasicDBObject newDocument = new BasicDBObject();
				newDocument.put("pdesc", pdesc);
				newDocument.put("price", price);
				 
				BasicDBObject updateObject = new BasicDBObject();
				updateObject.put("$set", newDocument);
				 
				collection.update(query, updateObject);
				return 1;
				
			}
			else
			{
				//pname not present
				cursor.close();
				return 0;
				
		}
		}
			catch(Exception e)
			{
				System.out.print(e);
			}
		
			return 0;	

	}
	
	public int deleteProduct(String pname)
	{
		try {
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("product");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("pname", pname);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{	
				collection.remove(searchQuery);
				return 1;
				
			}
			else
			{
				//pname not present
				cursor.close();
				return 0;
				
		}
		}
			catch(Exception e)
			{
				System.out.print(e);
			}
		
			return 0;	

	}
	
	
}
