package ecom;

import java.io.IOException;
import java.sql.Driver;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumJsoup {
	
	public static ArrayList<String> fetchAmazonReviews(String url, Integer number)
	{
		String prev_url,next_url;
		int count=0;
		ArrayList<String> reviews = new ArrayList<>();
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		try {
		
		
		driver.get(url);
		String xpathAllReviews="//*[@class='a-row a-spacing-base']/a";
		//driver.findElement(By.xpath(xpathAllReviews)).click();
		Thread.sleep(700);
		driver.findElementByLinkText("See all reviews").click();		
		Document page;

			String url_modified = driver.getCurrentUrl().toString();
			page = Jsoup.connect(url_modified).userAgent("Rohan").get();
			
			String reviewSelector = "a-profile-name";
			Elements reviewElements = page.getElementsByClass(reviewSelector);
			String reviewTitle = "a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold";
			Elements reviewTitlename = page.getElementsByClass(reviewTitle);
			
			if(reviewTitlename.size()<10)
			{
			int j;
			 for (j = 0; j < reviewTitlename.size(); j++) 
		        { 
				 count=count+1;
				 	reviews.add(reviewElements.get(j).text());
		            reviews.add(reviewTitlename.get(j).text()); 
		            number=number-1;
		            if(number==0 )
		            {
		            	break;
		            }
		        }
			}
			else
			{ 
				while(number>0)
				{
					
				url_modified = driver.getCurrentUrl().toString();
					page = Jsoup.connect(url_modified).userAgent("Rohan").get();
					
				 reviewSelector = "a-profile-name";
				 reviewElements = page.getElementsByClass(reviewSelector);
				 reviewTitle = "a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold";
				 reviewTitlename = page.getElementsByClass(reviewTitle);
				 int j = 0;
				 for (j = 0; j < reviewTitlename.size(); j++) 
			        { 
					 	count=count+1;
					 	reviews.add(reviewElements.get(j+2).text());
			            reviews.add(reviewTitlename.get(j).text()); 
			            number=number-1;
			            if(number==0 )
			            {
			            	break;
			            } 
			        }
				 	prev_url=driver.getCurrentUrl().toString();
				 	Thread.sleep(300);
					driver.findElement(By.className("a-last")).click();
					next_url=driver.getCurrentUrl().toString();
					if(next_url.equalsIgnoreCase(prev_url))
					{
						break;
					}
					else
					{
						page = Jsoup.connect(url_modified).userAgent("Rohan").get();
						 reviewSelector = "a-profile-name";
						 reviewElements = page.getElementsByClass(reviewSelector);
						 reviewTitle = "a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold";
						 reviewTitlename = page.getElementsByClass(reviewTitle);
						
					}
				}
			}
			
			
		}
		catch(NoSuchElementException ns)
		{
			String nos= Integer.toString(count);
			reviews.add(nos);
			driver.quit();
			return reviews;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			reviews.clear();
			reviews.add("error");
			driver.quit();
			return reviews;
		
		}
		String nos= Integer.toString(count);
		reviews.add(nos);
		driver.quit();
		return reviews;
	}
	
	public ArrayList<String> fetchCriticalReviews(String url, int number)
	{
		String prev_url,next_url;
		int count=0;
		ArrayList<String> reviews = new ArrayList<>();
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		try {
		
		driver.get(url);
		String xpathAllReviews="//*[@class='a-row a-spacing-base']/a";
		//driver.findElement(By.xpath(xpathAllReviews)).click();
		Thread.sleep(700);
		driver.findElementByLinkText("See all reviews").click();
		driver.get(driver.getCurrentUrl().toString()+"&filterByStar=critical&pageNumber=1");
		Document page;

			String url_modified = driver.getCurrentUrl().toString();
			page = Jsoup.connect(url_modified).userAgent("Rohan").get();
			
			String reviewSelector = "a-profile-name";
			Elements reviewElements = page.getElementsByClass(reviewSelector);
			String reviewTitle = "a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold";
			Elements reviewTitlename = page.getElementsByClass(reviewTitle);
			
			if(reviewTitlename.size()<10)
			{
			int j;
			 for (j = 0; j < reviewTitlename.size(); j++) 
		        { 
				 count=count+1;
				 	reviews.add(reviewElements.get(j).text());
		            reviews.add(reviewTitlename.get(j).text()); 
		            number=number-1;
		            if(number==0 )
		            {
		            	break;
		            }
		        }
			}
			else
			{	
				
				while(number>0)
				{
					
				url_modified = driver.getCurrentUrl().toString();
					page = Jsoup.connect(url_modified).userAgent("Rohan").get();
					
				 reviewSelector = "a-profile-name";
				 reviewElements = page.getElementsByClass(reviewSelector);
				 reviewTitle = "a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold";
				 reviewTitlename = page.getElementsByClass(reviewTitle);
				 int j = 0;
				 for (j = 0; j < reviewTitlename.size(); j++) 
			        { 
					 	count=count+1;
					 	reviews.add(reviewElements.get(j+2).text());
			            reviews.add(reviewTitlename.get(j).text()); 
			            number=number-1;
			            if(number==0 )
			            {
			            	break;
			            } 
			        }
				 	prev_url=driver.getCurrentUrl().toString();
				 	Thread.sleep(300);
					driver.findElement(By.className("a-last")).click();
				 	
					next_url=driver.getCurrentUrl().toString();
					if(next_url.equalsIgnoreCase(prev_url))
					{
						break;
					}
					else
					{
						page = Jsoup.connect(url_modified).userAgent("Rohan").get();
						 reviewSelector = "a-profile-name";
						 reviewElements = page.getElementsByClass(reviewSelector);
						 reviewTitle = "a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold";
						 reviewTitlename = page.getElementsByClass(reviewTitle);
						
					}
				}
			}
			
			
		}
		catch(NoSuchElementException ns)
		{
			String nos= Integer.toString(count);
			reviews.add(nos);
			System.out.println(ns);
			driver.quit();
			return reviews;
		}
		catch(Exception e)
		{
			reviews.clear();
			reviews.add("error");
			driver.quit();
			return reviews;
		
		}
		String nos= Integer.toString(count);
		reviews.add(nos);
		driver.quit();
		return reviews;
			
			
			
		
	}

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
		
		SeleniumJsoup sj = new SeleniumJsoup();
		System.out.println(sj.fetchCriticalReviews("https://www.amazon.in/Lenovo-Ideapad-Generation-Windows-81W800HFIN/product-reviews/B08698X4YX/ref=cm_cr_dp_d_show_all_btm?ie=UTF8&reviewerType=all_reviews",10));

}
}
