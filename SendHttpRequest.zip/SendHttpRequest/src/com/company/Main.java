package com.company;

import java.net.HttpURLConnection;
import java.net.URL;

public class Main {

	
	  public static HttpURLConnection connection; 
	  public static void main(String args[])
	  {
		  try
		  { 
			  URL url = new URL("https://jsonplaceholder.typicode.com/posts");
			  connection =(HttpURLConnection) url.openConnection();
			  connection.setRequestMethod("GET");
			  connection.setConnectTimeout(5000);
			  connection.setReadTimeout(5000);
	  
	  int status= connection.getResponseCode(); 
	  System.out.print(status);
	  }
		catch(Exception e)
		  { e.printStackTrace(); } 
		
		  finally {
	  connection.disconnect(); 
	  }
		  }
	 
	
	
}
