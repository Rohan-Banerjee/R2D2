module sendHttpRequest {
	requires java.net.http;
}