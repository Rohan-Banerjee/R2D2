package dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

import connection.connection;

public class user {
		
	public int emailValidate(String email, String password)
	{
		try {
		connection c = new connection();
		DB database = c.getConnection();
		DBCollection collection = database.getCollection("contacts");
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put("email", email);
		DBCursor cursor = collection.find(searchQuery);
		 
		if (cursor.hasNext()) {
//		  email exists  
			cursor.close();
			return 1;
				}
		else		{
		//email doesn't exist
		}
		
		
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		return 0;
		
	}
	
	public int verifyPassword(String email, String password)
	{
		try {
		
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("contacts");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("email", email);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{
				BasicDBObject dbo= new BasicDBObject();
				dbo = (BasicDBObject) cursor.next();
				cursor.close();
				String dbpassword = dbo.getString("password");
				if(password.equals(dbpassword))
				{
					return 1;
					
				}
				else
				{
					return 0;
				}
			}
		}
			catch(Exception e)
			{
				System.out.print(e);
			}
		
			return 0;	
	}
	public int saveEmployee(String email, String pass, String pass2 )
	{
		if(pass.equals(pass2))
		{
		try {
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("contacts");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("email", email);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{	
				cursor.close();
				return 0;
			}
			else
			{
				cursor.close();
			BasicDBObject document = new BasicDBObject();
			document.put("email", email);
			document.put("password", pass);
			collection.insert(document);
			return 1;
		}
		}
			catch(Exception e)
			{
				System.out.print(e);
			}
		}
		else
		{
			return -1;
		}
		
			return 0;	

	}
	
}
