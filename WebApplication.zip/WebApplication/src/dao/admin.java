package dao;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import connection.connection;

public class admin {
	
	public int validateAdminEmail(String email,String password)
	{
		try
		{
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("adminInfo");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("id", email);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{
				BasicDBObject dbo= new BasicDBObject();
				dbo = (BasicDBObject) cursor.next();
				String dbpassword = dbo.getString("pwd");
				if(dbpassword.equals(password))
				{
				return 1;	
				}
				else
				{
				return 0;
				}
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	
	
	public String searchName(String name)
	{
		String dbpassword="";
		try
		{
			
			connection c = new connection();
			DB database = c.getConnection();
			DBCollection collection = database.getCollection("contacts");
			BasicDBObject searchQuery = new BasicDBObject();
			searchQuery.put("email", name);
			DBCursor cursor = collection.find(searchQuery);
			if(cursor.hasNext())
			{
				BasicDBObject dbo= new BasicDBObject();
				dbo = (BasicDBObject) cursor.next();
				dbpassword = dbo.getString("password");
				return dbpassword ; 
			}
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
	

return dbpassword;
}
}
