$(document).ready(function(){
  $("button").click(function(){
    $("#div1").fadeIn(3000);
  });
});